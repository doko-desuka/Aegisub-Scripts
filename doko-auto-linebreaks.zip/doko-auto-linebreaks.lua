script_name = "(Doko) Auto Linebreaks"
script_author = "doko (2025)"
script_version = "0.1.0"
script_description = "Adds linebreaks if the line exceeds the set CPL (Characters Per Line)."

include("unicode.lua")
include("utils.lua")


function find_first_dialogue_index(subs)
    for index = 1, #subs do
        if subs[index].class == 'dialogue' then
            return index
        end
    end
    return nil
end


function exec(subs, sel, act)
    local first_index = find_first_dialogue_index(subs)
    if first_index == nil then
        aegisub.cancel()
    end

    local diag = {
        {class = 'label', label = 'Max. CPL', x = 0, y = 1, width = 1, height = 1},
        {
            class = 'intedit',
            name = 'max_cpl',
            hint = 'How many (non-space) characters to allow before adding a linebreak to the line',
            value = 50,
            x = 1, y = 1, width = 1, height = 1,
        },
    }
    local button, results = aegisub.dialog.display(diag)
    if button ~= false then
        local max_cpl = results['max_cpl']
        if max_cpl then
            for line_index = first_index, #subs do
                line = subs[line_index]
                if line.class == 'dialogue' and #line.text > 0 then
                    local iter = string.words(line.text)
                    local first_word = iter()
                    local temp_words = {first_word}
                    local temp_cpl = unicode.len(first_word)
                    local index = 1
                    for word in iter do
                        local length = unicode.len(word)
                        if temp_cpl + length > max_cpl then
                            temp_words[index] = temp_words[index] .. '\\n' .. word
                            temp_cpl = length
                        else
                            temp_cpl = temp_cpl + length
                            index = index + 1
                            temp_words[index] = word
                        end
                    end
                    line.text = table.concat(temp_words, ' ')
                    subs[line_index] = line
                end
            end
            return
        end
    end
    aegisub.cancel()
end


aegisub.register_macro("Auto Linebreaks", script_description, exec)
