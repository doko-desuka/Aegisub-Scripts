script_name = "(Doko) Re-Shift All To Time"
script_author = "doko (2025)"
script_version = "0.1.0"
script_description = "Shifts all subtitles so the first subtitle matches the input time."


function find_first_dialogue_index(subs)
    for index = 1, #subs do
        if subs[index].class == 'dialogue' then
            return index
        end
    end
    return nil
end


-- Converts HH:MM:SS.CC to milliseconds.
function time_to_ms(value)
    local hh, mm, ss, cc = value:match('(%d+):(%d+):(%d+)%.(%d+)')
    if (hh == nil or mm == nil or ss == nil or cc == nil) then
        -- Try an alternative, only SS.CC.
        ss, cc = value:match('(%d+)%.(%d+)')
        if (ss == nil or cc == nil) then
            return nil
        end
        hh = 0
        mm = 0
        ss = ss or 0
        cc = cc or 0
    end
    hh = tonumber(hh) * 1000 * 60 * 60
    mm = tonumber(mm) * 1000 * 60
    ss = tonumber(ss) * 1000
    cc = tonumber(cc) * 10
    return hh + mm + ss + cc
end


function exec(subs, sel, act)
    local first_index = find_first_dialogue_index(subs)
    if first_index == nil then
        aegisub.cancel()
    end

    local diag = {
        {class = 'label', label = 'Start Time (HH:MM:SS.CC)', x = 0, y = 1, width = 1, height = 1},
        {
            class = 'edit',
            name = 'starting_time',
            hint = 'Time that the first subtitle should start from. All subtitles will slide to that.',
            value = '00:00:00.00',
            x = 1, y = 1, width = 1, height = 1,
        },
    }
    local button, results = aegisub.dialog.display(diag)
    if button ~= false then
        local target_time = time_to_ms(results['starting_time'])
        if target_time then
            local offset = target_time - subs[first_index].start_time
            for line_index = first_index, #subs do
                line = subs[line_index]
                if line.class == 'dialogue' then
                    line.start_time = line.start_time + offset
                    line.end_time   = line.end_time + offset
                    subs[line_index] = line
                end
            end
            return
        end
    end
    aegisub.cancel()
end


aegisub.register_macro("Re-Shift All To Time", script_description, exec)
